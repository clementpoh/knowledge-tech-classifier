
# THIS FILE IS GENERATED FROM NUMPY SETUP.PY
short_version = '1.6.2rc1'
version = '1.6.2rc1'
full_version = '1.6.2rc1'
git_revision = '09bb26867d73173d74b4f9d4d481064e6044fa71'
release = True

if not release:
    version = full_version
