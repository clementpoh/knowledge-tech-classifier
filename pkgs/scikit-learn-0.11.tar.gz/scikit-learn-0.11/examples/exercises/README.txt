Tutorial exercices
------------------

Exercises for the tutorials
