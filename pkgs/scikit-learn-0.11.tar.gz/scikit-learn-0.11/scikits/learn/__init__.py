import warnings
warnings.warn('scikits.learn namespace is deprecated and will be removed in '
        '0.12, please use sklearn instead')
from sklearn import *
from sklearn import __version__
