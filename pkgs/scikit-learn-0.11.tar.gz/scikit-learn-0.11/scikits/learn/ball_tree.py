import warnings
warnings.warn('scikits.learn namespace is deprecated, please use sklearn instead')
from sklearn.neighbors.ball_tree import *
