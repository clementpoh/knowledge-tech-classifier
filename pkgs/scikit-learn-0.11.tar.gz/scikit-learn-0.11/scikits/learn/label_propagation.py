import warnings
warnings.warn('scikits.learn namespace is deprecated, please use sklearn instead')
from sklearn.semi_supervised.label_propagation import *
