import warnings
warnings.warn('scikits.learn namespace is deprecated, please use sklearn instead')
from sklearn.lda import *
